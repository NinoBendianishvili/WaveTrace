APP_NAME = "WaveTrace"
