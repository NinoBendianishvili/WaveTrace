from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import QWidget

from ableton_vcs.config.theme import *


class WaveformWidget(QWidget):
    def __init__(self):
        super().__init__()

        self.progress = 0.0
        self.setMinimumHeight(54)
        self.setMaximumHeight(64)

    def set_progress(self, progress):
        self.progress = max(0.0, min(1.0, progress))
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        width = self.width()
        height = self.height()

        center_y = height / 2
        bar_count = 34
        spacing = width / max(bar_count, 1)

        progress_x = width * self.progress

        for index in range(bar_count):
            x = index * spacing + spacing / 2

            pseudo_height = self.bar_height(index, height)

            if x <= progress_x:
                color = QColor(ACCENT)
            else:
                color = QColor(TEXT_SECONDARY)

            pen = QPen(color, 3)
            pen.setCapStyle(Qt.RoundCap)
            painter.setPen(pen)

            painter.drawLine(
                int(x),
                int(center_y - pseudo_height / 2),
                int(x),
                int(center_y + pseudo_height / 2),
            )

    def bar_height(self, index, height):
        pattern = [
            18, 25, 32, 20, 38, 29, 44, 24,
            35, 48, 28, 40, 52, 30, 46, 22,
            36, 50, 31, 42, 26, 39, 47, 24,
            34, 45, 29, 41, 21, 37, 49, 27,
            33, 43,
        ]

        value = pattern[index % len(pattern)]
        return min(value, height - 8)