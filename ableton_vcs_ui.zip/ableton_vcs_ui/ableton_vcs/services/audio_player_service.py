from pathlib import Path

from PySide6.QtCore import QUrl
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer


class AudioPlayerService:
    def __init__(self):
        self.player = QMediaPlayer()
        self.audio_output = QAudioOutput()

        self.player.setAudioOutput(self.audio_output)
        self.audio_output.setVolume(0.85)

    def play(self, audio_path):
        audio_path = Path(audio_path)

        if not audio_path.exists():
            raise FileNotFoundError(f"Audio file does not exist: {audio_path}")

        self.player.setSource(QUrl.fromLocalFile(str(audio_path)))
        self.player.play()

    def stop(self):
        self.player.stop()

    def is_playing(self):
        return self.player.playbackState() == QMediaPlayer.PlayingState